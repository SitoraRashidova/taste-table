export class CreateManagerDto {
  restaurant_id: string;
  full_name: string;
  email: string;
  password: string;
  confirm_password: string;
  is_active: boolean;
}
