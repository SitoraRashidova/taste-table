import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import e from 'express';
import mongoose, { HydratedDocument } from 'mongoose';
import { Restaurant } from '../../restoran/schemas/restoran.schema';

export type ManagerDocument = HydratedDocument<Manager>;

@Schema({ versionKey: false })
export class Manager {
  @Prop({
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Restaurant',
  })
  restaurant_id: Restaurant;
  @Prop()
  full_name: string;

  @Prop({ required: true, unique: true })
  email: string;

  @Prop()
  hashed_password: string;

  @Prop()
  hashed_refresh_token: string;

  @Prop({ default: true })
  is_active: boolean;
}

export const ManagerSchema = SchemaFactory.createForClass(Manager);
